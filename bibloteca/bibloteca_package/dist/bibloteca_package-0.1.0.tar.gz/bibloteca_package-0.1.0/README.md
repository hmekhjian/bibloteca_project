CLI tool for anaging your library
